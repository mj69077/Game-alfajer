extends Control

func _ready():
	$VBox/PlayButton.connect("pressed", self, "_on_play_pressed")

func _on_play_pressed():
	get_tree().change_scene("res://Levels/Level1.tscn")
