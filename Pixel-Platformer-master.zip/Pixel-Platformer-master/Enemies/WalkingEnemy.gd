extends CharacterBody2D

var direction = Vector2.RIGHT
var velocity = Vector2.ZERO

@onready var ledgeCheckRight: = $LedgeCheckRight
@onready var ledgeCheckLeft: = $LedgeCheckLeft
@onready var sprite: = $AnimatedSprite2D

func _physics_process(delta):
	var found_wall = is_on_wall()
	var found_ledge = not ledgeCheckRight.is_colliding() or not ledgeCheckLeft.is_colliding()
	
	if found_wall or found_ledge:
		direction *= -1
	
	sprite.flip_h = direction.x > 0
	
	velocity = direction * 25
	set_velocity(velocity)
	set_up_direction(Vector2.UP)
	move_and_slide()
