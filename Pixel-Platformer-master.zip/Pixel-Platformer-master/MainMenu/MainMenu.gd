extends Control

func _ready():
	$VBox/PlayButton.connect("pressed", Callable(self, "_on_play_pressed"))

func _on_play_pressed():
	get_tree().change_scene_to_file("res://Levels/Level1.tscn")
